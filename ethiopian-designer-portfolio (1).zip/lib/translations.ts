export type Language = "en" | "am"

export const translations = {
  en: {
    nav: {
      home: "Home",
      about: "About",
      portfolio: "Portfolio",
      contact: "Contact",
    },
    home: {
      hero: {
        title: "Ethiopian Fashion Designer",
        subtitle: "Blending Traditional Heritage with Contemporary Style",
        cta: "View Portfolio",
      },
      gallery: {
        title: "Featured Designs",
        subtitle: "Explore our latest collection of traditional and modern Ethiopian fashion",
      },
      testimonials: {
        title: "What Clients Say",
        subtitle: "Hear from those who have experienced our designs",
      },
      social: {
        title: "Follow Our Journey",
        subtitle: "Stay connected with our latest designs and updates",
      },
    },
    about: {
      title: "About Me",
      subtitle: "Crafting Stories Through Fashion",
      journey: {
        title: "My Journey",
        content:
          "With over a decade of experience in fashion design, I specialize in creating unique pieces that celebrate Ethiopian heritage while embracing contemporary aesthetics. Each design tells a story, weaving together traditional craftsmanship with modern innovation.",
      },
      philosophy: {
        title: "Design Philosophy",
        content:
          "I believe fashion is more than clothing—it's a form of cultural expression and personal identity. My work honors the rich textile traditions of Ethiopia while creating pieces that resonate with modern sensibilities.",
      },
    },
    portfolio: {
      title: "Portfolio",
      subtitle: "Browse our collection of traditional and contemporary designs",
      filters: {
        all: "All Designs",
        traditional: "Traditional Wear",
        casual: "Casual Wear",
        accessories: "Accessories",
      },
    },
    contact: {
      title: "Get In Touch",
      subtitle: "Let's create something beautiful together",
      form: {
        name: "Name",
        email: "Email",
        phone: "Phone",
        message: "Message",
        submit: "Send Message",
        success: "Message sent successfully!",
      },
      info: {
        email: "Email",
        phone: "Phone",
        location: "Location",
        hours: "Business Hours",
        hoursValue: "Mon - Sat: 9:00 AM - 6:00 PM",
      },
      social: "Follow Us",
    },
    footer: {
      tagline: "Celebrating Ethiopian heritage through contemporary fashion design",
      rights: "All rights reserved.",
      links: {
        privacy: "Privacy Policy",
        terms: "Terms of Service",
      },
    },
  },
  am: {
    nav: {
      home: "መነሻ",
      about: "ስለኔ",
      portfolio: "ስራዎች",
      contact: "አግኙን",
    },
    home: {
      hero: {
        title: "የኢትዮጵያ ፋሽን ዲዛይነር",
        subtitle: "ባህላዊ ቅርስን ከዘመናዊ ስታይል ጋር በማዋሃድ",
        cta: "ስራዎችን ይመልከቱ",
      },
      gallery: {
        title: "የተመረጡ ዲዛይኖች",
        subtitle: "የባህላዊ እና ዘመናዊ የኢትዮጵያ ፋሽን ስብስባችንን ይመልከቱ",
      },
      testimonials: {
        title: "ደንበኞች የሚሉት",
        subtitle: "ዲዛይኖቻችንን ከተሞከሩ ሰዎች ያዳምጡ",
      },
      social: {
        title: "ጉዞአችንን ይከተሉ",
        subtitle: "አዳዲስ ዲዛይኖችን እና ዝመናዎችን ይከታተሉ",
      },
    },
    about: {
      title: "ስለኔ",
      subtitle: "በፋሽን ታሪክ መፍጠር",
      journey: {
        title: "የእኔ ጉዞ",
        content:
          "ከአስር አመት በላይ በፋሽን ዲዛይን ልምድ ያለኝ፣ የኢትዮጵያን ቅርስ በማክበር ዘመናዊ ውበትን በመቀበል ልዩ ቁርጥራጮችን በመፍጠር ላይ አተኩራለሁ። እያንዳንዱ ዲዛይን ታሪክ ይነግራል፣ ባህላዊ እጅ ሥራን ከዘመናዊ ፈጠራ ጋር በማዋሃድ።",
      },
      philosophy: {
        title: "የዲዛይን ፍልስፍና",
        content:
          "ፋሽን ከልብስ በላይ እንደሆነ አምናለሁ - የባህል አገላለጽ እና የግል ማንነት ነው። ሥራዬ የኢትዮጵያን ሀብታም የጨርቃ ጨርቅ ባህሎችን ያከብራል እና ከዘመናዊ ስሜቶች ጋር የሚስማሙ ቁርጥራጮችን ይፈጥራል።",
      },
    },
    portfolio: {
      title: "ስራዎች",
      subtitle: "የባህላዊ እና ዘመናዊ ዲዛይኖች ስብስባችንን ይመልከቱ",
      filters: {
        all: "ሁሉም ዲዛይኖች",
        traditional: "ባህላዊ ልብስ",
        casual: "መደበኛ ልብስ",
        accessories: "መለዋወጫዎች",
      },
    },
    contact: {
      title: "አግኙን",
      subtitle: "አብረን የሚያምር ነገር እንፍጠር",
      form: {
        name: "ስም",
        email: "ኢሜይል",
        phone: "ስልክ",
        message: "መልእክት",
        submit: "መልእክት ላክ",
        success: "መልእክት በተሳካ ሁኔታ ተልኳል!",
      },
      info: {
        email: "ኢሜይል",
        phone: "ስልክ",
        location: "አድራሻ",
        hours: "የስራ ሰዓት",
        hoursValue: "ሰኞ - ቅዳሜ: 9:00 ጠዋት - 6:00 ምሽት",
      },
      social: "ይከተሉን",
    },
    footer: {
      tagline: "የኢትዮጵያን ቅርስ በዘመናዊ ፋሽን ዲዛይን በማክበር",
      rights: "መብቱ በህግ የተጠበቀ ነው።",
      links: {
        privacy: "የግላዊነት ፖሊሲ",
        terms: "የአገልግሎት ውል",
      },
    },
  },
}

export function getTranslation(lang: Language) {
  return translations[lang]
}
