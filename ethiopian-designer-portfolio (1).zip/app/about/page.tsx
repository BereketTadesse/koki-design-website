"use client"

import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Card } from "@/components/ui/card"
import Image from "next/image"
import { useLanguage } from "@/lib/language-context"
import { getTranslation } from "@/lib/translations"

export default function AboutPage() {
  const { language } = useLanguage()
  const t = getTranslation(language)

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-20 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h1 className="text-4xl md:text-5xl font-bold mb-6 text-balance">{t.about.title}</h1>
                <p className="text-lg text-muted-foreground leading-relaxed mb-6 text-pretty">{t.about.subtitle}</p>
                <p className="text-lg text-muted-foreground leading-relaxed mb-6 text-pretty">
                  {t.about.journey.content}
                </p>
                <p className="text-lg text-muted-foreground leading-relaxed text-pretty">
                  {t.about.philosophy.content}
                </p>
              </div>
              <div className="relative aspect-square rounded-lg overflow-hidden">
                <Image
                  src="/ethiopian-fashion-designer-portrait-in-studio.jpg"
                  alt="Ethiopian Designer Portrait"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Background Section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-muted/30">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-8 text-center text-balance">{t.about.journey.title}</h2>
            <div className="space-y-6 text-muted-foreground leading-relaxed">
              <p className="text-pretty">
                {language === "en"
                  ? "Growing up in Ethiopia, I was surrounded by the vibrant colors, intricate patterns, and rich textile traditions that have been passed down through generations. From an early age, I was fascinated by the way traditional habesha kemis and other garments told stories of our culture and identity."
                  : "በኢትዮጵያ ሲያድግ፣ በትውልድ የተላለፉ በደማቅ ቀለሞች፣ ውስብስብ ንድፎች እና ሀብታም የጨርቃ ጨርቅ ባህሎች ተከቦ ነበር። ከትንሽ እድሜ ጀምሮ፣ ባህላዊ ሀበሻ ቀሚስ እና ሌሎች ልብሶች የባህላችንን እና የማንነታችንን ታሪክ በሚነግሩበት መንገድ ተማርኩ።"}
              </p>
              <p className="text-pretty">
                {language === "en"
                  ? "After studying fashion design and working with master artisans across Ethiopia, I founded my design studio with a clear mission: to create fashion that honors our heritage while speaking to contemporary aesthetics. I work closely with local weavers, embroiderers, and craftspeople to ensure that every piece maintains the authenticity and quality that Ethiopian craftsmanship is known for."
                  : "የፋሽን ዲዛይን ከተማርኩ እና በኢትዮጵያ ውስጥ ካሉ ዋና የእጅ ባለሙያዎች ጋር ከሰራሁ በኋላ፣ የዲዛይን ስቱዲዮዬን በግልጽ ተልእኮ መሰረት አቋቋምኩ፡ ቅርሳችንን የሚያከብር እና ከዘመናዊ ውበት ጋር የሚነጋገር ፋሽን መፍጠር። የኢትዮጵያ እጅ ሥራ በሚታወቅበት ትክክለኛነት እና ጥራት እያንዳንዱ ቁራጭ እንዲጠብቅ ከአካባቢው ሸማቾች፣ ጌጣጌጥ ሰሪዎች እና የእጅ ባለሙያዎች ጋር በቅርበት እሰራለሁ።"}
              </p>
              <p className="text-pretty">
                {language === "en"
                  ? "My designs have been featured in fashion shows across East Africa and have been worn by individuals who appreciate the intersection of culture, quality, and style. Whether it's a modern interpretation of traditional wear or contemporary pieces inspired by Ethiopian motifs, each creation carries a piece of our story."
                  : "ዲዛይኖቼ በምስራቅ አፍሪካ ውስጥ በፋሽን ትርኢቶች ላይ ቀርበዋል እና ባህል፣ ጥራት እና ስታይል መገናኛን በሚያደንቁ ግለሰቦች ተለብሰዋል። የባህላዊ ልብስ ዘመናዊ ትርጉም ይሁን ወይም በኢትዮጵያ ንድፎች ተመስጦ የተፈጠሩ ዘመናዊ ቁርጥራጮች፣ እያንዳንዱ ፍጥረት የታሪካችንን ክፍል ይይዛል።"}
              </p>
            </div>
          </div>
        </section>

        {/* Design Philosophy */}
        <section className="py-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center text-balance">{t.about.philosophy.title}</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <Card className="p-6 border-border">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                  <svg
                    className="w-6 h-6 text-accent"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-3 text-balance">
                  {language === "en" ? "Cultural Heritage" : "የባህል ቅርስ"}
                </h3>
                <p className="text-muted-foreground leading-relaxed text-pretty">
                  {language === "en"
                    ? "Every design draws inspiration from Ethiopia's rich history, incorporating traditional patterns, techniques, and symbolism that have been cherished for centuries."
                    : "እያንዳንዱ ዲዛይን ከኢትዮጵያ ሀብታም ታሪክ ተመስጦ፣ ለዘመናት የተከበሩ ባህላዊ ንድፎችን፣ ቴክኒኮችን እና ምልክቶችን ያካትታል።"}
                </p>
              </Card>

              <Card className="p-6 border-border">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                  <svg
                    className="w-6 h-6 text-accent"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-3 text-balance">
                  {language === "en" ? "Artisan Craftsmanship" : "የእጅ ባለሙያ ስራ"}
                </h3>
                <p className="text-muted-foreground leading-relaxed text-pretty">
                  {language === "en"
                    ? "I collaborate with skilled Ethiopian artisans, ensuring that traditional techniques like hand-weaving and embroidery are preserved and celebrated in each piece."
                    : "እንደ እጅ መሸመን እና ጌጣጌጥ ያሉ ባህላዊ ቴክኒኮች በእያንዳንዱ ቁራጭ ውስጥ እንዲጠበቁ እና እንዲከበሩ በማድረግ ከችሎታ ያላቸው የኢትዮጵያ የእጅ ባለሙያዎች ጋር እተባበራለሁ።"}
                </p>
              </Card>

              <Card className="p-6 border-border">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                  <svg
                    className="w-6 h-6 text-accent"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-3 text-balance">
                  {language === "en" ? "Modern Innovation" : "ዘመናዊ ፈጠራ"}
                </h3>
                <p className="text-muted-foreground leading-relaxed text-pretty">
                  {language === "en"
                    ? "While rooted in tradition, my designs embrace contemporary silhouettes, sustainable practices, and versatile styling to meet the needs of modern life."
                    : "በባህል ላይ የተመሰረተ ቢሆንም፣ ዲዛይኖቼ የዘመናዊ ህይወትን ፍላጎት ለማሟላት ዘመናዊ ቅርጾችን፣ ዘላቂ ልምዶችን እና ሁለገብ ስታይልን ይቀበላሉ።"}
                </p>
              </Card>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
