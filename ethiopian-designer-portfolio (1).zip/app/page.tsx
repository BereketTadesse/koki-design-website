"use client"

import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { GalleryModal } from "@/components/gallery-modal"
import { Testimonials } from "@/components/testimonials"
import { SocialFeed } from "@/components/social-feed"
import { StructuredData } from "@/components/structured-data"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import Link from "next/link"
import { useState } from "react"
import { ArrowRight } from "lucide-react"
import { useLanguage } from "@/lib/language-context"
import { getTranslation } from "@/lib/translations"

const portfolioItems = [
  {
    id: 1,
    src: "/ethiopian-traditional-dress-with-modern-twist.jpg",
    alt: "Traditional Ethiopian dress with contemporary design",
    title: "Heritage Collection",
    description:
      "A modern interpretation of traditional Ethiopian habesha kemis, featuring intricate hand-woven patterns and contemporary silhouettes.",
    category: "Traditional Wear",
  },
  {
    id: 2,
    src: "/ethiopian-casual-fashion-design.jpg",
    alt: "Casual Ethiopian-inspired fashion",
    title: "Urban Elegance",
    description:
      "Contemporary casual wear inspired by Ethiopian colors and patterns, perfect for everyday sophistication.",
    category: "Casual Wear",
  },
  {
    id: 3,
    src: "/ethiopian-handmade-accessories-jewelry.jpg",
    alt: "Handmade Ethiopian accessories",
    title: "Artisan Accessories",
    description:
      "Handcrafted jewelry and accessories featuring traditional Ethiopian metalwork and beading techniques.",
    category: "Accessories",
  },
  {
    id: 4,
    src: "/ethiopian-wedding-dress-traditional.jpg",
    alt: "Ethiopian wedding attire",
    title: "Bridal Elegance",
    description: "Exquisite bridal wear combining traditional Ethiopian wedding customs with modern bridal fashion.",
    category: "Traditional Wear",
  },
  {
    id: 5,
    src: "/ethiopian-modern-casual-outfit.jpg",
    alt: "Modern Ethiopian casual design",
    title: "Contemporary Fusion",
    description: "Bold, modern designs that celebrate Ethiopian heritage through innovative fabric choices and cuts.",
    category: "Casual Wear",
  },
  {
    id: 6,
    src: "/ethiopian-leather-accessories-bags.jpg",
    alt: "Ethiopian leather goods",
    title: "Leather Crafts",
    description: "Premium leather bags and accessories showcasing traditional Ethiopian leatherworking expertise.",
    category: "Accessories",
  },
]

export default function HomePage() {
  const [selectedImage, setSelectedImage] = useState<(typeof portfolioItems)[0] | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const { language } = useLanguage()
  const t = getTranslation(language)

  const handleImageClick = (item: (typeof portfolioItems)[0]) => {
    setSelectedImage(item)
    setIsModalOpen(true)
  }

  return (
    <>
      <StructuredData />
      <div className="min-h-screen flex flex-col">
        <Navigation />

        <main className="flex-1">
          {/* Hero Section */}
          <section className="relative py-20 md:py-32 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto">
              <div className="max-w-3xl">
                <h1 className="text-4xl md:text-6xl font-bold mb-6 text-balance">{t.home.hero.title}</h1>
                <p className="text-lg md:text-xl text-muted-foreground mb-8 leading-relaxed text-pretty">
                  {t.home.hero.subtitle}
                </p>
                <div className="flex flex-wrap gap-4">
                  <Button asChild size="lg">
                    <Link href="/portfolio">
                      {t.home.hero.cta}
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                  <Button asChild variant="outline" size="lg">
                    <Link href="/contact">{t.contact.title}</Link>
                  </Button>
                </div>
              </div>
            </div>
          </section>

          {/* Featured Gallery */}
          <section className="py-16 px-4 sm:px-6 lg:px-8 bg-muted/30">
            <div className="max-w-7xl mx-auto">
              <div className="flex items-center justify-between mb-12">
                <div>
                  <h2 className="text-3xl md:text-4xl font-bold mb-3 text-balance">{t.home.gallery.title}</h2>
                  <p className="text-muted-foreground text-pretty">{t.home.gallery.subtitle}</p>
                </div>
                <Button asChild variant="ghost">
                  <Link href="/portfolio">
                    {language === "en" ? "View All" : "ሁሉንም ይመልከቱ"}
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {portfolioItems.map((item) => (
                  <Card
                    key={item.id}
                    className="group cursor-pointer overflow-hidden border-border hover:shadow-lg transition-all duration-300"
                    onClick={() => handleImageClick(item)}
                  >
                    <div className="relative aspect-square overflow-hidden bg-muted">
                      <Image
                        src={item.src || "/placeholder.svg"}
                        alt={item.alt}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div className="p-5">
                      <div className="inline-block px-2 py-1 bg-accent/10 text-accent text-xs font-medium rounded mb-2">
                        {item.category}
                      </div>
                      <h3 className="text-lg font-semibold mb-2 text-balance">{item.title}</h3>
                      <p className="text-sm text-muted-foreground line-clamp-2 text-pretty">{item.description}</p>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </section>

          {/* Testimonials Section */}
          <Testimonials />

          {/* Social Feed Section */}
          <SocialFeed />

          {/* CTA Section */}
          <section className="py-20 px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">
                {language === "en" ? "Ready to Create Something Beautiful?" : "የሚያምር ነገር ለመፍጠር ዝግጁ ነዎት?"}
              </h2>
              <p className="text-lg text-muted-foreground mb-8 text-pretty">
                {language === "en"
                  ? "Let's collaborate to bring your vision to life with authentic Ethiopian design."
                  : "እውነተኛ የኢትዮጵያ ዲዛይን ጋር ራዕይዎን ወደ ህይወት ለማምጣት እንተባበር።"}
              </p>
              <Button asChild size="lg">
                <Link href="/contact">
                  {language === "en" ? "Start a Project" : "ፕሮጀክት ይጀምሩ"}
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </section>
        </main>

        <Footer />

        <GalleryModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} image={selectedImage} />
      </div>
    </>
  )
}
