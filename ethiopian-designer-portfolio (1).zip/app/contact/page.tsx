"use client"

import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { ContactForm } from "@/components/contact-form"
import { Card } from "@/components/ui/card"
import { Mail, Phone, MapPin, Facebook, Instagram, Send } from "lucide-react"
import { useLanguage } from "@/lib/language-context"
import { getTranslation } from "@/lib/translations"

export default function ContactPage() {
  const { language } = useLanguage()
  const t = getTranslation(language)

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      <main className="flex-1">
        {/* Header */}
        <section className="py-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-balance">{t.contact.title}</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">{t.contact.subtitle}</p>
          </div>
        </section>

        {/* Contact Content */}
        <section className="px-4 sm:px-6 lg:px-8 pb-20">
          <div className="max-w-7xl mx-auto">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Contact Information */}
              <div className="lg:col-span-1 space-y-6">
                <Card className="p-6 border-border">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Mail className="h-5 w-5 text-accent" />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-1">{t.contact.info.email}</h3>
                      <a
                        href="mailto:info@ethiopiandesigner.com"
                        className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                      >
                        info@ethiopiandesigner.com
                      </a>
                    </div>
                  </div>
                </Card>

                <Card className="p-6 border-border">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Phone className="h-5 w-5 text-accent" />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-1">{t.contact.info.phone}</h3>
                      <a
                        href="tel:+251911234567"
                        className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                      >
                        +251 911 234 567
                      </a>
                    </div>
                  </div>
                </Card>

                <Card className="p-6 border-border">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <MapPin className="h-5 w-5 text-accent" />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-1">{t.contact.info.location}</h3>
                      <p className="text-sm text-muted-foreground">
                        {language === "en" ? "Addis Ababa, Ethiopia" : "አዲስ አበባ፣ ኢትዮጵያ"}
                      </p>
                    </div>
                  </div>
                </Card>

                <Card className="p-6 border-border">
                  <h3 className="font-semibold mb-4">{t.contact.social}</h3>
                  <div className="flex gap-4">
                    <a
                      href="https://facebook.com"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center text-accent hover:bg-accent hover:text-accent-foreground transition-colors"
                      aria-label="Facebook"
                    >
                      <Facebook className="h-5 w-5" />
                    </a>
                    <a
                      href="https://instagram.com"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center text-accent hover:bg-accent hover:text-accent-foreground transition-colors"
                      aria-label="Instagram"
                    >
                      <Instagram className="h-5 w-5" />
                    </a>
                    <a
                      href="https://t.me/ethiopiandesigner"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center text-accent hover:bg-accent hover:text-accent-foreground transition-colors"
                      aria-label="Telegram"
                    >
                      <Send className="h-5 w-5" />
                    </a>
                  </div>
                </Card>

                <Card className="p-6 border-border bg-accent/5">
                  <h3 className="font-semibold mb-2">{t.contact.info.hours}</h3>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <div className="flex justify-between">
                      <span>{language === "en" ? "Monday - Friday" : "ሰኞ - አርብ"}</span>
                      <span>9:00 AM - 6:00 PM</span>
                    </div>
                    <div className="flex justify-between">
                      <span>{language === "en" ? "Saturday" : "ቅዳሜ"}</span>
                      <span>10:00 AM - 4:00 PM</span>
                    </div>
                    <div className="flex justify-between">
                      <span>{language === "en" ? "Sunday" : "እሁድ"}</span>
                      <span>{language === "en" ? "Closed" : "ዝግ"}</span>
                    </div>
                  </div>
                </Card>
              </div>

              {/* Contact Form */}
              <div className="lg:col-span-2">
                <Card className="p-8 border-border">
                  <h2 className="text-2xl font-bold mb-2 text-balance">
                    {language === "en" ? "Send Us a Message" : "መልእክት ይላኩልን"}
                  </h2>
                  <p className="text-muted-foreground mb-6 text-pretty">
                    {language === "en"
                      ? "Fill out the form below and we'll get back to you as soon as possible."
                      : "ከዚህ በታች ያለውን ቅጽ ይሙሉ እና በተቻለ ፍጥነት እናገኝዎታለን።"}
                  </p>
                  <ContactForm />
                </Card>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
