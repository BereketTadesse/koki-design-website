"use client"

import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { GalleryModal } from "@/components/gallery-modal"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import { useState } from "react"
import { useLanguage } from "@/lib/language-context"
import { getTranslation } from "@/lib/translations"

const portfolioItems = [
  {
    id: 1,
    src: "/ethiopian-traditional-dress-with-modern-twist.jpg",
    alt: "Traditional Ethiopian dress with contemporary design",
    title: "Heritage Collection",
    description:
      "A modern interpretation of traditional Ethiopian habesha kemis, featuring intricate hand-woven patterns and contemporary silhouettes that honor our cultural legacy.",
    category: "Traditional Wear",
  },
  {
    id: 2,
    src: "/ethiopian-casual-fashion-design.jpg",
    alt: "Casual Ethiopian-inspired fashion",
    title: "Urban Elegance",
    description:
      "Contemporary casual wear inspired by Ethiopian colors and patterns, perfect for everyday sophistication. Blends comfort with cultural pride.",
    category: "Casual Wear",
  },
  {
    id: 3,
    src: "/ethiopian-handmade-accessories-jewelry.jpg",
    alt: "Handmade Ethiopian accessories",
    title: "Artisan Accessories",
    description:
      "Handcrafted jewelry and accessories featuring traditional Ethiopian metalwork and beading techniques passed down through generations.",
    category: "Accessories",
  },
  {
    id: 4,
    src: "/ethiopian-wedding-dress-traditional.jpg",
    alt: "Ethiopian wedding attire",
    title: "Bridal Elegance",
    description:
      "Exquisite bridal wear combining traditional Ethiopian wedding customs with modern bridal fashion. Each piece is a celebration of love and heritage.",
    category: "Traditional Wear",
  },
  {
    id: 5,
    src: "/ethiopian-modern-casual-outfit.jpg",
    alt: "Modern Ethiopian casual design",
    title: "Contemporary Fusion",
    description:
      "Bold, modern designs that celebrate Ethiopian heritage through innovative fabric choices and cuts. Perfect for the fashion-forward individual.",
    category: "Casual Wear",
  },
  {
    id: 6,
    src: "/ethiopian-leather-accessories-bags.jpg",
    alt: "Ethiopian leather goods",
    title: "Leather Crafts",
    description:
      "Premium leather bags and accessories showcasing traditional Ethiopian leatherworking expertise with contemporary functionality.",
    category: "Accessories",
  },
  {
    id: 7,
    src: "/ethiopian-traditional-habesha-kemis-dress-white-wi.jpg",
    alt: "Traditional habesha kemis",
    title: "Classic Habesha",
    description:
      "Timeless habesha kemis featuring traditional tibeb embroidery in vibrant colors. A staple of Ethiopian formal wear.",
    category: "Traditional Wear",
  },
  {
    id: 8,
    src: "/ethiopian-inspired-modern-blazer-with-traditional-.jpg",
    alt: "Modern Ethiopian blazer",
    title: "Executive Style",
    description:
      "Professional wear with Ethiopian flair. This blazer incorporates subtle traditional patterns into a contemporary business silhouette.",
    category: "Casual Wear",
  },
  {
    id: 9,
    src: "/ethiopian-handwoven-scarf-shawl-with-traditional-p.jpg",
    alt: "Handwoven Ethiopian scarf",
    title: "Woven Heritage",
    description:
      "Luxurious handwoven scarves and shawls featuring traditional Ethiopian weaving patterns. Perfect for any season.",
    category: "Accessories",
  },
]

export default function PortfolioPage() {
  const { language } = useLanguage()
  const t = getTranslation(language)
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [selectedImage, setSelectedImage] = useState<(typeof portfolioItems)[0] | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const categories = [
    t.portfolio.filters.all,
    t.portfolio.filters.traditional,
    t.portfolio.filters.casual,
    t.portfolio.filters.accessories,
  ]

  const categoryMap: Record<string, string> = {
    [t.portfolio.filters.all]: "All",
    [t.portfolio.filters.traditional]: "Traditional Wear",
    [t.portfolio.filters.casual]: "Casual Wear",
    [t.portfolio.filters.accessories]: "Accessories",
  }

  const filteredItems =
    selectedCategory === t.portfolio.filters.all
      ? portfolioItems
      : portfolioItems.filter((item) => item.category === categoryMap[selectedCategory])

  const handleImageClick = (item: (typeof portfolioItems)[0]) => {
    setSelectedImage(item)
    setIsModalOpen(true)
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      <main className="flex-1">
        {/* Header */}
        <section className="py-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-balance">{t.portfolio.title}</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">{t.portfolio.subtitle}</p>
          </div>
        </section>

        {/* Category Filter */}
        <section className="px-4 sm:px-6 lg:px-8 pb-12">
          <div className="max-w-7xl mx-auto">
            <div className="flex flex-wrap justify-center gap-3">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  onClick={() => setSelectedCategory(category)}
                  className="min-w-[120px]"
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>
        </section>

        {/* Portfolio Grid */}
        <section className="px-4 sm:px-6 lg:px-8 pb-20">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredItems.map((item) => (
                <Card
                  key={item.id}
                  className="group cursor-pointer overflow-hidden border-border hover:shadow-lg transition-all duration-300"
                  onClick={() => handleImageClick(item)}
                >
                  <div className="relative aspect-square overflow-hidden bg-muted">
                    <Image
                      src={item.src || "/placeholder.svg"}
                      alt={item.alt}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="p-5">
                    <div className="inline-block px-2 py-1 bg-accent/10 text-accent text-xs font-medium rounded mb-2">
                      {item.category}
                    </div>
                    <h3 className="text-lg font-semibold mb-2 text-balance">{item.title}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-2 text-pretty">{item.description}</p>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />

      <GalleryModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} image={selectedImage} />
    </div>
  )
}
