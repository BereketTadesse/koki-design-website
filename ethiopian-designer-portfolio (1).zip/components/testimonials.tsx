import { Card } from "@/components/ui/card"
import { Star } from "lucide-react"
import Image from "next/image"

const testimonials = [
  {
    id: 1,
    name: "Selam Tesfaye",
    role: "Fashion Enthusiast",
    image: "/ethiopian-woman-customer-testimonial-portrait.jpg",
    content:
      "The attention to detail and cultural authenticity in every piece is remarkable. I wore a custom habesha kemis to my sister's wedding and received countless compliments. Truly exceptional craftsmanship!",
    rating: 5,
  },
  {
    id: 2,
    name: "Michael Abebe",
    role: "Business Professional",
    content:
      "I commissioned a modern suit with traditional Ethiopian patterns for an important conference. The result was stunning - professional yet uniquely cultural. The designer perfectly understood my vision.",
    rating: 5,
  },
  {
    id: 3,
    name: "Hanna Bekele",
    role: "Bride",
    image: "/ethiopian-bride-customer-testimonial-portrait.jpg",
    content:
      "My wedding dress was a dream come true. The designer created a perfect blend of traditional and contemporary styles that honored my heritage while feeling modern and elegant. I felt absolutely beautiful!",
    rating: 5,
  },
  {
    id: 4,
    name: "David Girma",
    role: "Art Collector",
    content:
      "The accessories collection is extraordinary. Each piece tells a story and showcases the incredible skill of Ethiopian artisans. I've purchased several items as gifts and they're always treasured.",
    rating: 5,
  },
]

export function Testimonials() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-muted/30">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-3 text-balance">What Our Clients Say</h2>
          <p className="text-muted-foreground text-pretty">
            Hear from those who have experienced our designs firsthand
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {testimonials.map((testimonial) => (
            <Card key={testimonial.id} className="p-6 border-border">
              <div className="flex gap-1 mb-4">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-accent text-accent" />
                ))}
              </div>

              <p className="text-muted-foreground mb-6 leading-relaxed text-pretty">{testimonial.content}</p>

              <div className="flex items-center gap-3">
                {testimonial.image ? (
                  <div className="relative w-12 h-12 rounded-full overflow-hidden bg-muted">
                    <Image
                      src={testimonial.image || "/placeholder.svg"}
                      alt={testimonial.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                ) : (
                  <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center">
                    <span className="text-accent font-semibold">{testimonial.name.charAt(0)}</span>
                  </div>
                )}
                <div>
                  <p className="font-semibold">{testimonial.name}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
