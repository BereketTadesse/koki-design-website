"use client"

import { Dialog, DialogContent } from "@/components/ui/dialog"
import Image from "next/image"
import { X } from "lucide-react"
import { Button } from "@/components/ui/button"

interface GalleryModalProps {
  isOpen: boolean
  onClose: () => void
  image: {
    src: string
    alt: string
    title: string
    description: string
    category: string
  } | null
}

export function GalleryModal({ isOpen, onClose, image }: GalleryModalProps) {
  if (!image) return null

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl p-0 overflow-hidden">
        <Button
          variant="ghost"
          size="icon"
          className="absolute right-4 top-4 z-10 bg-background/80 backdrop-blur-sm"
          onClick={onClose}
        >
          <X className="h-4 w-4" />
        </Button>
        <div className="grid md:grid-cols-2 gap-0">
          <div className="relative aspect-square bg-muted">
            <Image src={image.src || "/placeholder.svg"} alt={image.alt} fill className="object-cover" />
          </div>
          <div className="p-6 md:p-8 flex flex-col justify-center">
            <div className="inline-block px-3 py-1 bg-accent/10 text-accent text-xs font-medium rounded-full mb-4 w-fit">
              {image.category}
            </div>
            <h2 className="text-2xl font-semibold mb-3 text-balance">{image.title}</h2>
            <p className="text-muted-foreground leading-relaxed text-pretty">{image.description}</p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
