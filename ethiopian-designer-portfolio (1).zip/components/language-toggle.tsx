"use client"

import { Button } from "@/components/ui/button"
import { useLanguage } from "@/lib/language-context"
import { Languages } from "lucide-react"

export function LanguageToggle() {
  const { language, setLanguage } = useLanguage()

  return (
    <Button variant="ghost" size="sm" onClick={() => setLanguage(language === "en" ? "am" : "en")} className="gap-2">
      <Languages className="h-4 w-4" />
      <span className="font-medium">{language === "en" ? "አማርኛ" : "English"}</span>
    </Button>
  )
}
